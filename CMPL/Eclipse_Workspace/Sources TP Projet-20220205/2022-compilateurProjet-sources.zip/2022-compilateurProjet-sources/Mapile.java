/**
 * La classe Mapile permet l'execution de la machine a pile virtuelle MAPILE
 *  
 * @author Girard, Masson, Perraudeau
 *
 */
 
public class Mapile  {
 

    // necessite les classes ExecMapile.class (dans libClass_projet) et Mnemo.class 
    
    public static void main (String[] args) {
	ExecMapile.activer();
    }
    
} // Mapile
